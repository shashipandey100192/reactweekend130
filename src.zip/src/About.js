import React from "react";

const a = ()=>{
    alert("hirrrrrrrrrr");
    }

class Myclass extends React.Component
{
    
    render()
    {
       
        return <h1 onClick={a}>This is class Component in react .js  </h1>
    }
}
export default Myclass
