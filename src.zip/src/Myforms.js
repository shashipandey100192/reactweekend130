import React, { Fragment } from 'react'
import "./style.css";

function Myforms() {
  return (
    <Fragment>
    <div>Myforms</div>
    <h1 className='h1'>this is form element</h1>
    </Fragment>
  )
}

export default Myforms